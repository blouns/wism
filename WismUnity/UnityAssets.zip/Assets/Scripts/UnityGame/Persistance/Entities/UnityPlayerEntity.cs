﻿namespace Assets.Scripts.UnityGame.Persistance.Entities
{
    public class UnityPlayerEntity
    {
        public string ClanName { get; set; }

        public bool IsHuman { get; set; }
    }
}

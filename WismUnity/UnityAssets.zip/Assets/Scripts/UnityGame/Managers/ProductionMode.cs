﻿namespace Assets.Scripts.Managers
{
    public enum ProductionMode
    {
        None,
        SelectCity,
        CitySelected,
        SelectProduction
    }
}

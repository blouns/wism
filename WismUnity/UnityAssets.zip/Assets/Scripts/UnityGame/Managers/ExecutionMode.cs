﻿namespace Assets.Scripts.Managers
{
    public enum ExecutionMode
    {
        NotStarted,
        Bootstrap,
        Starting,
        Running,
        Editor
    }
}

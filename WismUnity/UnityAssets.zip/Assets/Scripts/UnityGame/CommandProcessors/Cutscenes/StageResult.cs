﻿namespace Assets.Scripts.CommandProcessors
{
    public enum SceneResult
    {
        Start,
        Continue,
        Wait,
        Yes,
        No,
        Success,
        Failure
    }
}

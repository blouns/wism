﻿namespace Assets.Scripts.UI
{
    public enum OkCancel
    {
        None,
        Picking,
        Ok,
        Cancel
    }
}